# Smart Expense Tracker

A portfolio-ready full-stack expense tracking web application.

## Tech stack
- Frontend: React, TypeScript, Vite, React Router, Axios, Recharts, Lucide
- Backend: Python, FastAPI, SQLAlchemy
- Database: SQLite (created automatically)
- Authentication: JWT bearer tokens and hashed passwords

## Features
- User registration and login
- Dashboard with balance, income, expense and savings summary
- Monthly income/expense trend chart
- Expense category breakdown
- Add, edit and delete transactions
- Search and filter transactions
- Monthly category budgets with usage progress
- User-specific data protected by JWT authentication
- Responsive layout

## Requirements
- Node.js 18+
- Python 3.10+
- npm

## Run locally

### 1. Backend
Open a terminal in `backend`:

Windows:
```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn app.main:app --reload
```

macOS/Linux:
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

API: http://127.0.0.1:8000  
Swagger documentation: http://127.0.0.1:8000/docs

The SQLite database `backend/expense_tracker.db` is created automatically.

### 2. Frontend
Open a second terminal in `frontend`:

```bash
npm install
npm run dev
```

Open the URL Vite prints (usually http://localhost:5173).

## First use
1. Register with your name, email and password.
2. Sign in.
3. Add income and expense transactions.
4. Explore the dashboard, transactions and budgets.

## API endpoints
- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/auth/me`
- `GET /api/dashboard?month=YYYY-MM`
- `GET|POST /api/transactions`
- `PUT|DELETE /api/transactions/{id}`
- `GET|POST /api/budgets`
- `DELETE /api/budgets/{id}`
- `GET /api/health`

## Notes before submission
This is a learning/portfolio project. Before deploying publicly, configure a strong `SECRET_KEY`, restrict CORS to your frontend domain, use HTTPS, add database migrations, and review security/rate-limiting settings. The default SQLite database is local development storage.
