export type User = { id: number; name: string; email: string }
export type Transaction = {
  id: number; title: string; amount: number; kind: 'income' | 'expense'
  category: string; txn_date: string; note: string
}
export type DashboardData = {
  month: string; income: number; expense: number; balance: number; savings_rate: number
  category_breakdown: { category: string; amount: number }[]
  recent_transactions: { id: number; title: string; amount: number; kind: string; category: string; txn_date: string }[]
}
export type Budget = { id: number; month: string; category: string; amount: number }
