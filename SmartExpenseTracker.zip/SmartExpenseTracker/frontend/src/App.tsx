import { useEffect, useMemo, useState, type FormEvent } from 'react'
import { NavLink, Route, Routes, useNavigate } from 'react-router-dom'
import { LayoutDashboard, ArrowLeftRight, WalletCards, LogOut, Plus, Search, Trash2, Pencil, X, TrendingUp, TrendingDown, Wallet, Menu, PiggyBank } from 'lucide-react'
import { Area, AreaChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis, PieChart, Pie, Cell } from 'recharts'
import api from './api'
import type { Budget, DashboardData, Transaction, User } from './types'

const money = (n: number) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n)
const currentMonth = () => new Date().toISOString().slice(0, 7)
const today = () => new Date().toISOString().slice(0, 10)
const categories = ['Food', 'Transport', 'Shopping', 'Bills', 'Health', 'Entertainment', 'Education', 'Salary', 'Freelance', 'Other']
const palette = ['#6c63ff', '#22a06b', '#f59e0b', '#ec6b8b', '#38a3a5', '#8b5cf6', '#64748b']

function App() {
  const [user, setUser] = useState<User | null>(() => {
    const raw = localStorage.getItem('expense_user'); return raw ? JSON.parse(raw) : null
  })
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login')
  const [authError, setAuthError] = useState('')
  const [authBusy, setAuthBusy] = useState(false)
  const navigate = useNavigate()

  const logout = () => { localStorage.removeItem('expense_token'); localStorage.removeItem('expense_user'); setUser(null); navigate('/') }

  if (!user) return <AuthScreen mode={authMode} setMode={setAuthMode} error={authError} busy={authBusy}
    onSubmit={async (data) => {
      setAuthBusy(true); setAuthError('')
      try {
        const path = authMode === 'register' ? '/auth/register' : '/auth/login'
        const response = await api.post(path, data)
        localStorage.setItem('expense_token', response.data.access_token)
        localStorage.setItem('expense_user', JSON.stringify(response.data.user))
        setUser(response.data.user)
      } catch (e: any) { setAuthError(e.response?.data?.detail || 'Unable to sign in. Check that the backend is running.') }
      finally { setAuthBusy(false) }
    }} />

  return <AppShell user={user} logout={logout} />
}

function AuthScreen({ mode, setMode, error, busy, onSubmit }: {
  mode: 'login' | 'register'; setMode: (m: 'login' | 'register') => void; error: string; busy: boolean
  onSubmit: (data: any) => Promise<void>
}) {
  const [name, setName] = useState(''); const [email, setEmail] = useState(''); const [password, setPassword] = useState('')
  const submit = (e: FormEvent) => { e.preventDefault(); onSubmit(mode === 'register' ? { name, email, password } : { email, password }) }
  return <main className="auth-wrap">
    <section className="auth-card">
      <div className="brand-mark"><WalletCards size={25}/></div>
      <p className="eyebrow">PERSONAL FINANCE, MADE CLEAR</p>
      <h1>{mode === 'login' ? 'Welcome back' : 'Create your account'}</h1>
      <p className="muted">{mode === 'login' ? 'Sign in to see where your money goes.' : 'Start building better money habits today.'}</p>
      <form onSubmit={submit} className="form-stack">
        {mode === 'register' && <label>Full name<input value={name} onChange={e=>setName(e.target.value)} placeholder="Your name" minLength={2} required /></label>}
        <label>Email address<input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com" required /></label>
        <label>Password<input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="At least 8 characters" minLength={8} required /></label>
        {error && <p className="error">{error}</p>}
        <button className="primary-btn full" disabled={busy}>{busy ? 'Please wait…' : mode === 'login' ? 'Sign in' : 'Create account'}</button>
      </form>
      <p className="auth-switch">{mode === 'login' ? "New here?" : 'Already have an account?'} <button onClick={()=>setMode(mode === 'login' ? 'register' : 'login')}>{mode === 'login' ? 'Create an account' : 'Sign in'}</button></p>
    </section>
    <aside className="auth-aside"><div className="aside-orb orb-one"/><div className="aside-orb orb-two"/>
      <div className="aside-content"><span className="aside-label">YOUR MONEY, IN FOCUS</span><h2>Small steps.<br/>Stronger finances.</h2><p>Track spending, plan your budget and make confident decisions with one simple view.</p>
      <div className="mini-stat"><span>Monthly savings</span><strong>↑ Build your future</strong></div></div>
    </aside>
  </main>
}

function AppShell({ user, logout }: { user: User; logout: () => void }) {
  const [page, setPage] = useState('dashboard')
  const [month, setMonth] = useState(currentMonth())
  const [mobileOpen, setMobileOpen] = useState(false)
  const [refresh, setRefresh] = useState(0)
  const [showForm, setShowForm] = useState(false)
  const [editItem, setEditItem] = useState<Transaction | null>(null)
  const [toast, setToast] = useState('')
  const [dashboard, setDashboard] = useState<DashboardData | null>(null)
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [budgets, setBudgets] = useState<Budget[]>([])
  const [loading, setLoading] = useState(true)
  const [apiError, setApiError] = useState('')

  useEffect(() => {
    let active = true
    setLoading(true); setApiError('')
    Promise.all([
      api.get('/dashboard', { params: { month } }),
      api.get('/transactions', { params: { month } }),
      api.get('/budgets', { params: { month } }),
    ]).then(([d,t,b]) => {
      if (!active) return
      setDashboard(d.data); setTransactions(t.data); setBudgets(b.data)
    }).catch((e) => {
      if (!active) return
      if (e.response?.status === 401) logout()
      else setApiError('Could not load your data. Check that the backend is running.')
    }).finally(()=>active && setLoading(false))
    return () => { active = false }
  }, [month, refresh])

  const notify = (message: string) => { setToast(message); window.setTimeout(()=>setToast(''), 2600) }
  const navItems = [
    { id: 'dashboard', label: 'Overview', icon: LayoutDashboard },
    { id: 'transactions', label: 'Transactions', icon: ArrowLeftRight },
    { id: 'budgets', label: 'Budgets', icon: WalletCards },
  ]
  const title = navItems.find(n=>n.id===page)?.label || 'Overview'

  return <div className="app-layout">
    <aside className={`sidebar ${mobileOpen ? 'open' : ''}`}>
      <div className="sidebar-brand"><div className="brand-mark small"><WalletCards size={20}/></div><span>pennywise<span className="brand-dot">.</span></span></div>
      <div className="side-caption">WORKSPACE</div>
      <nav>{navItems.map(n=><button key={n.id} className={`nav-item ${page===n.id?'active':''}`} onClick={()=>{setPage(n.id);setMobileOpen(false)}}><n.icon size={18}/>{n.label}</button>)}</nav>
      <div className="sidebar-bottom"><div className="user-chip"><div className="avatar">{user.name.charAt(0).toUpperCase()}</div><div className="user-meta"><strong>{user.name}</strong><span>{user.email}</span></div></div><button className="logout-btn" onClick={logout}><LogOut size={17}/> Sign out</button></div>
    </aside>
    <main className="main-area">
      <header className="topbar"><button className="mobile-menu" onClick={()=>setMobileOpen(!mobileOpen)}><Menu/></button><div><p className="breadcrumb">Workspace / <strong>{title}</strong></p><h1>{title}</h1></div>
        <div className="top-actions"><label className="month-picker"><span>Month</span><input type="month" value={month} onChange={e=>setMonth(e.target.value)}/></label><button className="primary-btn add-top" onClick={()=>{setEditItem(null);setShowForm(true)}}><Plus size={17}/> Add transaction</button></div>
      </header>
      {apiError && <div className="notice error-notice">{apiError}</div>}
      {loading ? <div className="loading-state">Loading your financial overview…</div> : <>
        {page === 'dashboard' && <Dashboard data={dashboard} transactions={transactions} onNavigate={setPage} />}
        {page === 'transactions' && <Transactions items={transactions} onAdd={()=>{setEditItem(null);setShowForm(true)}} onEdit={item=>{setEditItem(item);setShowForm(true)}} onRefresh={()=>setRefresh(v=>v+1)} notify={notify}/>}
        {page === 'budgets' && <Budgets items={budgets} transactions={transactions} month={month} onRefresh={()=>setRefresh(v=>v+1)} notify={notify}/>}
      </>}
    </main>
    {showForm && <TransactionModal item={editItem} onClose={()=>setShowForm(false)} onSaved={()=>{setShowForm(false);setRefresh(v=>v+1);notify(editItem?'Transaction updated':'Transaction added')}}/>}
    {toast && <div className="toast">{toast}</div>}
  </div>
}

function Dashboard({ data, transactions, onNavigate }: { data: DashboardData | null; transactions: Transaction[]; onNavigate: (p:string)=>void }) {
  const chartData = useMemo(()=> {
    const map = new Map<string,{day:string; income:number; expense:number}>()
    transactions.forEach(t=>{const key=t.txn_date.slice(8,10);const v=map.get(key)||{day:key,income:0,expense:0};v[t.kind]+=t.amount;map.set(key,v)})
    return [...map.values()].sort((a,b)=>a.day.localeCompare(b.day))
  },[transactions])
  const cards = [
    {label:'Total balance',value:data?.balance||0,icon:Wallet,style:'violet',hint:'Income minus expenses'},
    {label:'Total income',value:data?.income||0,icon:TrendingUp,style:'green',hint:'Money received this month'},
    {label:'Total expenses',value:data?.expense||0,icon:TrendingDown,style:'orange',hint:'Money spent this month'},
  ]
  return <div className="page-content">
    <div className="welcome-row"><div><h2>Your financial snapshot</h2><p className="muted">Here’s how your money is doing this month.</p></div><span className="savings-pill"><PiggyBank size={16}/> {data?.savings_rate||0}% savings rate</span></div>
    <section className="stat-grid">{cards.map(c=><article className="stat-card" key={c.label}><div className="stat-top"><span>{c.label}</span><span className={`stat-icon ${c.style}`}><c.icon size={19}/></span></div><strong>{money(c.value)}</strong><small>{c.hint}</small></article>)}</section>
    <section className="content-grid">
      <article className="panel chart-panel"><div className="panel-heading"><div><h3>Cash flow</h3><p className="muted">Income and expenses by day</p></div><span className="legend"><i className="legend-income"/> Income <i className="legend-expense"/> Expenses</span></div>
        {chartData.length ? <div className="chart-wrap"><ResponsiveContainer width="100%" height="100%"><AreaChart data={chartData}><defs><linearGradient id="incomeFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#27a879" stopOpacity={0.2}/><stop offset="95%" stopColor="#27a879" stopOpacity={0}/></linearGradient><linearGradient id="expenseFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#f2a44a" stopOpacity={0.2}/><stop offset="95%" stopColor="#f2a44a" stopOpacity={0}/></linearGradient></defs><CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#edf0f5"/><XAxis dataKey="day" tickLine={false} axisLine={false}/><YAxis tickLine={false} axisLine={false} tickFormatter={v=>`₹${v/1000}k`}/><Tooltip formatter={(v:any)=>money(Number(v))}/><Area type="monotone" dataKey="income" stroke="#27a879" fill="url(#incomeFill)" strokeWidth={2.5}/><Area type="monotone" dataKey="expense" stroke="#eea24b" fill="url(#expenseFill)" strokeWidth={2.5}/></AreaChart></ResponsiveContainer></div> : <Empty text="Add transactions to see your cash flow chart."/>}
      </article>
      <article className="panel category-panel"><div className="panel-heading"><div><h3>Spending by category</h3><p className="muted">Where your money goes</p></div></div>
        {data?.category_breakdown.length ? <><div className="donut-wrap"><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={data.category_breakdown} dataKey="amount" nameKey="category" innerRadius={58} outerRadius={83} paddingAngle={3}>{data.category_breakdown.map((_,i)=><Cell key={i} fill={palette[i%palette.length]}/>)}</Pie><Tooltip formatter={(v:any)=>money(Number(v))}/></PieChart></ResponsiveContainer></div><div className="category-legend">{data.category_breakdown.slice(0,5).map((c,i)=><div key={c.category}><span><i style={{background:palette[i%palette.length]}}/>{c.category}</span><strong>{money(c.amount)}</strong></div>)}</div></> : <Empty text="Your category breakdown will appear here."/>}
      </article>
    </section>
    <section className="panel recent-panel"><div className="panel-heading"><div><h3>Recent transactions</h3><p className="muted">Your latest activity this month</p></div><button className="text-btn" onClick={()=>onNavigate('transactions')}>View all →</button></div>
      <TransactionTable items={transactions.slice(0,5)} compact/>
    </section>
  </div>
}

function Transactions({ items, onAdd, onEdit, onRefresh, notify }: { items: Transaction[]; onAdd:()=>void; onEdit:(t:Transaction)=>void; onRefresh:()=>void; notify:(s:string)=>void }) {
  const [query,setQuery]=useState(''); const [filter,setFilter]=useState('all')
  const filtered=items.filter(t=>(filter==='all'||t.kind===filter)&&(`${t.title} ${t.category}`.toLowerCase().includes(query.toLowerCase())))
  const remove=async(id:number)=>{if(!confirm('Delete this transaction?'))return;try{await api.delete(`/transactions/${id}`);onRefresh();notify('Transaction deleted')}catch{notify('Could not delete transaction')}}
  return <div className="page-content"><div className="welcome-row"><div><h2>All transactions</h2><p className="muted">Keep track of every rupee coming in and going out.</p></div><button className="primary-btn" onClick={onAdd}><Plus size={17}/> Add transaction</button></div>
    <section className="panel"><div className="table-toolbar"><div className="search-box"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search transactions…"/></div><select value={filter} onChange={e=>setFilter(e.target.value)}><option value="all">All types</option><option value="income">Income</option><option value="expense">Expenses</option></select></div>
      <TransactionTable items={filtered} onEdit={onEdit} onDelete={remove}/>{!filtered.length&&<Empty text="No matching transactions. Add one to get started."/>}
    </section>
  </div>
}

function TransactionTable({ items, compact=false, onEdit, onDelete }: {items:Transaction[];compact?:boolean;onEdit?:(t:Transaction)=>void;onDelete?:(id:number)=>void}) {
  if(!items.length)return <Empty text="No transactions yet. Your activity will show up here."/>
  return <div className="table-scroll"><table className="transaction-table"><thead><tr><th>TRANSACTION</th><th>CATEGORY</th><th>DATE</th><th>AMOUNT</th>{!compact&&<th>ACTIONS</th>}</tr></thead><tbody>{items.map(t=><tr key={t.id}><td><div className="transaction-name"><span className={`transaction-symbol ${t.kind}`}>{t.kind==='income'?'+':'−'}</span><strong>{t.title}</strong></div></td><td><span className="category-tag">{t.category}</span></td><td>{new Date(t.txn_date+'T00:00:00').toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'})}</td><td className={t.kind==='income'?'amount-income':'amount-expense'}>{t.kind==='income'?'+':'−'}{money(t.amount)}</td>{!compact&&<td><div className="row-actions"><button title="Edit" onClick={()=>onEdit?.(t)}><Pencil size={15}/></button><button title="Delete" onClick={()=>onDelete?.(t.id)}><Trash2 size={15}/></button></div></td>}</tr>)}</tbody></table></div>
}

function Budgets({items,transactions,month,onRefresh,notify}:{items:Budget[];transactions:Transaction[];month:string;onRefresh:()=>void;notify:(s:string)=>void}) {
  const [category,setCategory]=useState('Food');const [amount,setAmount]=useState('')
  const spent=(cat:string)=>transactions.filter(t=>t.kind==='expense'&&t.category===cat).reduce((s,t)=>s+t.amount,0)
  const save=async(e:FormEvent)=>{e.preventDefault();try{await api.post('/budgets',{month,category,amount:Number(amount)});setAmount('');onRefresh();notify('Budget saved')}catch{notify('Could not save budget')}}
  const remove=async(id:number)=>{try{await api.delete(`/budgets/${id}`);onRefresh();notify('Budget removed')}catch{notify('Could not remove budget')}}
  return <div className="page-content"><div className="welcome-row"><div><h2>Monthly budgets</h2><p className="muted">Set category limits and keep your spending on track.</p></div></div>
    <section className="panel budget-create"><div><h3>Create a budget</h3><p className="muted">Choose a category and set a monthly spending limit.</p></div><form onSubmit={save} className="budget-form"><label>Category<select value={category} onChange={e=>setCategory(e.target.value)}>{categories.filter(c=>!['Salary','Freelance'].includes(c)).map(c=><option key={c}>{c}</option>)}</select></label><label>Monthly limit<input type="number" min="1" step="1" value={amount} onChange={e=>setAmount(e.target.value)} placeholder="e.g. 5000" required/></label><button className="primary-btn">Save budget</button></form></section>
    <div className="budget-grid">{items.map(b=>{const used=spent(b.category);const pct=Math.min(100,used/b.amount*100);return <article className="panel budget-card" key={b.id}><div className="budget-card-top"><div><span className="category-tag">{b.category}</span><h3>{money(used)} <small>of {money(b.amount)}</small></h3></div><button className="icon-btn" onClick={()=>remove(b.id)} title="Remove budget"><Trash2 size={16}/></button></div><div className="progress-track"><div className={`progress-fill ${pct>=100?'over':pct>=80?'near':''}`} style={{width:`${pct}%`}}/></div><div className="budget-foot"><span>{pct.toFixed(0)}% used</span><span>{money(Math.max(0,b.amount-used))} left</span></div></article>})}</div>
    {!items.length&&<div className="panel"><Empty text="No budgets yet. Create your first monthly budget above."/></div>}
  </div>
}

function TransactionModal({item,onClose,onSaved}:{item:Transaction|null;onClose:()=>void;onSaved:()=>void}) {
  const [title,setTitle]=useState(item?.title||'');const [amount,setAmount]=useState(item?String(item.amount):'')
  const [kind,setKind]=useState<'income'|'expense'>(item?.kind||'expense');const [category,setCategory]=useState(item?.category||'Food')
  const [txnDate,setTxnDate]=useState(item?.txn_date||today());const [note,setNote]=useState(item?.note||'')
  const [error,setError]=useState('');const [busy,setBusy]=useState(false)
  const available=kind==='income'?['Salary','Freelance','Investment','Other']:categories.filter(c=>!['Salary','Freelance'].includes(c))
  const submit=async(e:FormEvent)=>{e.preventDefault();setBusy(true);setError('');const payload={title,amount:Number(amount),kind,category,txn_date:txnDate,note};try{if(item)await api.put(`/transactions/${item.id}`,payload);else await api.post('/transactions',payload);onSaved()}catch(e:any){setError(e.response?.data?.detail||'Could not save transaction')}finally{setBusy(false)}}
  return <div className="modal-backdrop" onMouseDown={e=>e.target===e.currentTarget&&onClose()}><section className="modal"><div className="modal-heading"><div><p className="eyebrow">TRANSACTION DETAILS</p><h2>{item?'Edit transaction':'Add transaction'}</h2></div><button className="icon-btn" onClick={onClose}><X/></button></div>
    <form onSubmit={submit} className="form-stack"><div className="segmented"><button type="button" className={kind==='expense'?'selected expense-selected':''} onClick={()=>{setKind('expense');setCategory('Food')}}>Expense</button><button type="button" className={kind==='income'?'selected income-selected':''} onClick={()=>{setKind('income');setCategory('Salary')}}>Income</button></div>
      <label>Description<input value={title} onChange={e=>setTitle(e.target.value)} placeholder="e.g. Grocery shopping" required maxLength={160}/></label>
      <div className="two-fields"><label>Amount (₹)<input type="number" min="0.01" step="0.01" value={amount} onChange={e=>setAmount(e.target.value)} placeholder="0.00" required/></label><label>Category<select value={category} onChange={e=>setCategory(e.target.value)}>{available.map(c=><option key={c}>{c}</option>)}</select></label></div>
      <label>Date<input type="date" value={txnDate} onChange={e=>setTxnDate(e.target.value)} required/></label>
      <label>Note <span className="muted">(optional)</span><textarea value={note} onChange={e=>setNote(e.target.value)} rows={2} placeholder="Add a note…"/></label>
      {error&&<p className="error">{error}</p>}<div className="modal-actions"><button type="button" className="secondary-btn" onClick={onClose}>Cancel</button><button className="primary-btn" disabled={busy}>{busy?'Saving…':item?'Save changes':'Add transaction'}</button></div>
    </form></section></div>
}

function Empty({text}:{text:string}) { return <div className="empty-state"><div className="empty-icon"><Wallet size={22}/></div><p>{text}</p></div> }

export default App
