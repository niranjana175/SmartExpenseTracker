from datetime import date
from calendar import monthrange
from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from .database import Base, engine, get_db
from . import models, schemas
from .auth import hash_password, verify_password, create_access_token, get_current_user

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Smart Expense Tracker API", version="1.0.0",
              description="Personal finance tracking API with JWT authentication")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def root():
    return {"message": "Smart Expense Tracker API", "docs": "/docs"}

@app.get("/api/health")
def health():
    return {"status": "ok"}

@app.post("/api/auth/register", response_model=schemas.TokenOut, status_code=201)
def register(payload: schemas.RegisterIn, db: Session = Depends(get_db)):
    email = payload.email.lower()
    if db.scalar(select(models.User).where(models.User.email == email)):
        raise HTTPException(409, "An account with this email already exists.")
    user = models.User(name=payload.name.strip(), email=email,
                       password_hash=hash_password(payload.password))
    db.add(user)
    db.commit()
    db.refresh(user)
    return {"access_token": create_access_token(user.id), "user": user}

@app.post("/api/auth/login", response_model=schemas.TokenOut)
def login(payload: schemas.LoginIn, db: Session = Depends(get_db)):
    user = db.scalar(select(models.User).where(models.User.email == payload.email.lower()))
    if not user or not verify_password(payload.password, user.password_hash):
        raise HTTPException(401, "Incorrect email or password.")
    return {"access_token": create_access_token(user.id), "user": user}

@app.get("/api/auth/me", response_model=schemas.UserOut)
def me(user: models.User = Depends(get_current_user)):
    return user

@app.get("/api/transactions", response_model=list[schemas.TransactionOut])
def list_transactions(month: str | None = None, kind: str | None = None,
                      q: str | None = None, db: Session = Depends(get_db),
                      user: models.User = Depends(get_current_user)):
    stmt = select(models.Transaction).where(models.Transaction.user_id == user.id)
    if month:
        stmt = stmt.where(models.Transaction.txn_date >= date.fromisoformat(month + "-01"))
        year, mon = map(int, month.split("-"))
        last_day = monthrange(year, mon)[1]
        stmt = stmt.where(models.Transaction.txn_date <= date(year, mon, last_day))
    if kind in ("income", "expense"):
        stmt = stmt.where(models.Transaction.kind == kind)
    if q:
        stmt = stmt.where(models.Transaction.title.ilike(f"%{q}%"))
    stmt = stmt.order_by(models.Transaction.txn_date.desc(), models.Transaction.id.desc())
    return list(db.scalars(stmt).all())

@app.post("/api/transactions", response_model=schemas.TransactionOut, status_code=201)
def create_transaction(payload: schemas.TransactionIn, db: Session = Depends(get_db),
                       user: models.User = Depends(get_current_user)):
    item = models.Transaction(**payload.model_dump(), user_id=user.id)
    db.add(item)
    db.commit()
    db.refresh(item)
    return item

@app.put("/api/transactions/{transaction_id}", response_model=schemas.TransactionOut)
def update_transaction(transaction_id: int, payload: schemas.TransactionIn,
                       db: Session = Depends(get_db), user: models.User = Depends(get_current_user)):
    item = db.scalar(select(models.Transaction).where(
        models.Transaction.id == transaction_id, models.Transaction.user_id == user.id))
    if not item:
        raise HTTPException(404, "Transaction not found.")
    for key, value in payload.model_dump().items():
        setattr(item, key, value)
    db.commit()
    db.refresh(item)
    return item

@app.delete("/api/transactions/{transaction_id}")
def delete_transaction(transaction_id: int, db: Session = Depends(get_db),
                       user: models.User = Depends(get_current_user)):
    item = db.scalar(select(models.Transaction).where(
        models.Transaction.id == transaction_id, models.Transaction.user_id == user.id))
    if not item:
        raise HTTPException(404, "Transaction not found.")
    db.delete(item)
    db.commit()
    return {"message": "Transaction deleted."}

@app.get("/api/budgets", response_model=list[schemas.BudgetOut])
def list_budgets(month: str, db: Session = Depends(get_db),
                 user: models.User = Depends(get_current_user)):
    return list(db.scalars(select(models.Budget).where(
        models.Budget.user_id == user.id, models.Budget.month == month
    ).order_by(models.Budget.category)).all())

@app.post("/api/budgets", response_model=schemas.BudgetOut)
def create_or_update_budget(payload: schemas.BudgetIn, db: Session = Depends(get_db),
                            user: models.User = Depends(get_current_user)):
    item = db.scalar(select(models.Budget).where(
        models.Budget.user_id == user.id,
        models.Budget.month == payload.month,
        models.Budget.category == payload.category
    ))
    if item:
        item.amount = payload.amount
    else:
        item = models.Budget(**payload.model_dump(), user_id=user.id)
        db.add(item)
    db.commit()
    db.refresh(item)
    return item

@app.delete("/api/budgets/{budget_id}")
def delete_budget(budget_id: int, db: Session = Depends(get_db),
                  user: models.User = Depends(get_current_user)):
    item = db.scalar(select(models.Budget).where(
        models.Budget.id == budget_id, models.Budget.user_id == user.id))
    if not item:
        raise HTTPException(404, "Budget not found.")
    db.delete(item)
    db.commit()
    return {"message": "Budget deleted."}

@app.get("/api/dashboard")
def dashboard(month: str, db: Session = Depends(get_db),
              user: models.User = Depends(get_current_user)):
    year, mon = map(int, month.split("-"))
    start = date(year, mon, 1)
    end = date(year, mon, monthrange(year, mon)[1])
    transactions = list(db.scalars(select(models.Transaction).where(
        models.Transaction.user_id == user.id,
        models.Transaction.txn_date >= start,
        models.Transaction.txn_date <= end
    )).all())
    income = sum(t.amount for t in transactions if t.kind == "income")
    expense = sum(t.amount for t in transactions if t.kind == "expense")
    categories = {}
    for t in transactions:
        if t.kind == "expense":
            categories[t.category] = categories.get(t.category, 0) + t.amount
    return {
        "month": month,
        "income": round(income, 2),
        "expense": round(expense, 2),
        "balance": round(income - expense, 2),
        "savings_rate": round(((income - expense) / income) * 100, 1) if income else 0,
        "category_breakdown": [{"category": k, "amount": round(v, 2)}
                               for k, v in sorted(categories.items(), key=lambda x: x[1], reverse=True)],
        "recent_transactions": [
            {"id": t.id, "title": t.title, "amount": t.amount, "kind": t.kind,
             "category": t.category, "txn_date": t.txn_date.isoformat()}
            for t in sorted(transactions, key=lambda x: (x.txn_date, x.id), reverse=True)[:6]
        ]
    }
