from datetime import date
from typing import Literal
from pydantic import BaseModel, EmailStr, Field, ConfigDict

class RegisterIn(BaseModel):
    name: str = Field(min_length=2, max_length=100)
    email: EmailStr
    password: str = Field(min_length=8, max_length=128)

class LoginIn(BaseModel):
    email: EmailStr
    password: str

class UserOut(BaseModel):
    id: int
    name: str
    email: EmailStr
    model_config = ConfigDict(from_attributes=True)

class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut

class TransactionIn(BaseModel):
    title: str = Field(min_length=1, max_length=160)
    amount: float = Field(gt=0)
    kind: Literal["income", "expense"]
    category: str = Field(min_length=1, max_length=80)
    txn_date: date
    note: str = Field(default="", max_length=500)

class TransactionOut(TransactionIn):
    id: int
    model_config = ConfigDict(from_attributes=True)

class BudgetIn(BaseModel):
    month: str = Field(pattern=r"^\d{4}-\d{2}$")
    category: str = Field(min_length=1, max_length=80)
    amount: float = Field(gt=0)

class BudgetOut(BudgetIn):
    id: int
    model_config = ConfigDict(from_attributes=True)
